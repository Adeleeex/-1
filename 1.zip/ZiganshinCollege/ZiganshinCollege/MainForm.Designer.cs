﻿namespace ZiganshinCollege
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DisciplineBtn = new Button();
            TeacherBtn = new Button();
            StudentBtn = new Button();
            GeneralTableAutoGridView = new DataGridView();
            BackBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)GeneralTableAutoGridView).BeginInit();
            SuspendLayout();
            // 
            // DisciplineBtn
            // 
            DisciplineBtn.BackColor = Color.White;
            DisciplineBtn.Location = new Point(12, 177);
            DisciplineBtn.Name = "DisciplineBtn";
            DisciplineBtn.Size = new Size(114, 25);
            DisciplineBtn.TabIndex = 9;
            DisciplineBtn.Text = "Discipline";
            DisciplineBtn.UseVisualStyleBackColor = false;
            DisciplineBtn.Click += DisciplineBtn_Click;
            // 
            // TeacherBtn
            // 
            TeacherBtn.BackColor = Color.White;
            TeacherBtn.Location = new Point(12, 125);
            TeacherBtn.Name = "TeacherBtn";
            TeacherBtn.Size = new Size(114, 25);
            TeacherBtn.TabIndex = 8;
            TeacherBtn.Text = "Teacher";
            TeacherBtn.UseVisualStyleBackColor = false;
            TeacherBtn.Click += TeacherBtn_Click;
            // 
            // StudentBtn
            // 
            StudentBtn.BackColor = Color.White;
            StudentBtn.Location = new Point(12, 68);
            StudentBtn.Name = "StudentBtn";
            StudentBtn.Size = new Size(114, 25);
            StudentBtn.TabIndex = 7;
            StudentBtn.Text = "Student";
            StudentBtn.UseVisualStyleBackColor = false;
            StudentBtn.Click += StudentBtn_Click;
            // 
            // GeneralTableAutoGridView
            // 
            GeneralTableAutoGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            GeneralTableAutoGridView.Location = new Point(137, 49);
            GeneralTableAutoGridView.Name = "GeneralTableAutoGridView";
            GeneralTableAutoGridView.Size = new Size(631, 463);
            GeneralTableAutoGridView.TabIndex = 6;
            // 
            // BackBtn
            // 
            BackBtn.BackColor = Color.White;
            BackBtn.Location = new Point(753, -1);
            BackBtn.Name = "BackBtn";
            BackBtn.Size = new Size(31, 25);
            BackBtn.TabIndex = 10;
            BackBtn.Text = "Х";
            BackBtn.UseVisualStyleBackColor = false;
            BackBtn.Click += BackBtn_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(784, 561);
            Controls.Add(BackBtn);
            Controls.Add(DisciplineBtn);
            Controls.Add(TeacherBtn);
            Controls.Add(StudentBtn);
            Controls.Add(GeneralTableAutoGridView);
            Name = "MainForm";
            Text = "MainForm";
            ((System.ComponentModel.ISupportInitialize)GeneralTableAutoGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button DisciplineBtn;
        private Button TeacherBtn;
        private Button StudentBtn;
        private DataGridView GeneralTableAutoGridView;
        private Button BackBtn;
    }
}