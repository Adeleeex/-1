﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZaitsevAutoRepairShops;

namespace ZiganshinCollege
{
    public partial class MainForm : Form
    {
        public static SQLiteConnection DB = new SQLiteConnection(DataBase.connection);
        public MainForm()
        {
            InitializeComponent();
            DB.Open();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void StudentBtn_Click(object sender, EventArgs e)
        {
            GeneralTableAutoGridView.DataSource = null;
            SQLiteCommand copy = new SQLiteCommand(@"SELECT * FROM Student", DB);
            copy.ExecuteNonQuery();
            SQLiteDataReader reader1 = copy.ExecuteReader();
            DataTable table1 = new DataTable();
            table1.Load(reader1);
            GeneralTableAutoGridView.DataSource = table1;
        }

        private void TeacherBtn_Click(object sender, EventArgs e)
        {
            GeneralTableAutoGridView.DataSource = null;
            SQLiteCommand copy = new SQLiteCommand(@"SELECT * FROM Teacher", DB);
            copy.ExecuteNonQuery();
            SQLiteDataReader reader1 = copy.ExecuteReader();
            DataTable table1 = new DataTable();
            table1.Load(reader1);
            GeneralTableAutoGridView.DataSource = table1;
        }

        private void DisciplineBtn_Click(object sender, EventArgs e)
        {
            GeneralTableAutoGridView.DataSource = null;
            SQLiteCommand copy = new SQLiteCommand(@"SELECT * FROM Discipline", DB);
            copy.ExecuteNonQuery();
            SQLiteDataReader reader1 = copy.ExecuteReader();
            DataTable table1 = new DataTable();
            table1.Load(reader1);
            GeneralTableAutoGridView.DataSource = table1;
        }
    }
}
