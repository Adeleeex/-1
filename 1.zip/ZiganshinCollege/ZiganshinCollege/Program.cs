using System.Data.SqlTypes;
using System.Windows.Forms;
using System.Data.SQLite;
using ZiganshinCollege;

namespace ZaitsevAutoRepairShops
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
        public static SQLiteConnection DB = new SQLiteConnection(DataBase.connection);
    }
    class DataBase
    {
        public static string connection = @"Data source = database.db";
    }
}